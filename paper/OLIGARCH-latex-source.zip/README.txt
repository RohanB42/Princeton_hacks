OLIGARCH anonymous review manuscript

Compile with pdfLaTeX (not XeLaTeX or LuaLaTeX):
  pdflatex -interaction=nonstopmode -halt-on-error oligarch.tex
  bibtex oligarch
  pdflatex -interaction=nonstopmode -halt-on-error oligarch.tex
  pdflatex -interaction=nonstopmode -halt-on-error oligarch.tex

Requires a standard TeX Live installation with the supplied AAAI-27 style dependencies.
The style automatically selects aaai2027.bst. Includes the Related Work section.
References start on a new page in this review draft; remove the explicit break for camera-ready.
No private paths, raw assay data or model weights are included.
